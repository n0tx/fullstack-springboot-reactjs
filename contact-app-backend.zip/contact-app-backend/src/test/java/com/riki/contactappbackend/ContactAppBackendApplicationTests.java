package com.riki.contactappbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactAppBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
